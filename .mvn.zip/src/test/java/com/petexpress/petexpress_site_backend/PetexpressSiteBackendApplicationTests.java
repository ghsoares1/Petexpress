package com.petexpress.petexpress_site_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetexpressSiteBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
